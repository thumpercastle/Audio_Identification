from fingerprinting import fingerprintBuilder
from matching import audioIdentification

fingerprintBuilder('C://Users/tonyr\OneDrive\MSc\MIR\Coursework_2\GTZAN_subset_pop\database_recordings',
                   "C://Users\\tonyr\OneDrive\MSc\MIR\Coursework_2\\fingerprints\pop\database_fingerprints")
audioIdentification("C://Users\\tonyr\OneDrive\MSc\MIR\Coursework_2\\fingerprints\pop\query_fingerprints",
                "C://Users\\tonyr\OneDrive\MSc\MIR\Coursework_2\\fingerprints\pop\database_fingerprints",
                    "C://Users\\tonyr\OneDrive\MSc\MIR\Coursework_2\output.txt")