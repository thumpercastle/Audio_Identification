import numpy as np
import os
from pickle_jar import store_file, read_file


def audioIdentification(queries_filepath, database_filepath, output_txt_path):

    query_name = ""
    document_name = ""
    query_fingerprint = {}
    document_fingerprint = {}
    scores = {}
    percentage_correct = 0
    number_of_queries_matched = 0
    # For each pickle in the query folder
    for query in os.listdir(queries_filepath):
        # if it is not a pickle, skip it.
        if os.path.splitext(os.path.basename(query))[1] != ".bpk":
            continue
        else:
            # Assign its name to the variable
            query_name = os.path.splitext(os.path.basename(query))[0]
            # print(f"query name: {query_name}")
            # Read the pickle of the query fingerprint
            path = str(queries_filepath + "\\" + query_name + ".bpk")
            # print(path)
            query_fingerprint = read_file(query_name, queries_filepath)
            # print(f"query_fingerprint type: {type(query_fingerprint)}")
            # print(f"size: {len(query_fingerprint)}")
            for document in os.listdir(database_filepath):
                if os.path.splitext(os.path.basename(document))[1] != ".bpk":
                    # print("this is not bpk")
                    continue
                else:
                    # print("this IS bpk. continuing with matching function")
                    document_name = os.path.splitext(os.path.basename(document))[0]
                    # print(document_name)
                    # Read the pickle of the document fingerprint
                    document_fingerprint = read_file(document_name, database_filepath)
                    # print(f"document_fingerprint type: {type(document_fingerprint)}, size: {len(document_fingerprint)}")
                    # compute matching function for this query and document combo
                    matching_score = matching_function(query_fingerprint, document_fingerprint)
                    # add the score to the scores dictionary
                    scores[document_name] = matching_score
                    # print(f"scores dictionary: {scores}")
        # Find the top 3 scores and their song names
        # print("checkpoint X")
        scores_list = list(scores.values())
        # print(f"scores_list: {scores_list}")
        # print(f"scores_list size: {len(scores_list)}")
        # print(f"SCORES FOR QUERY: {query_name}")
        query_name = os.path.splitext(os.path.basename(query))[0] + ".wav"
        evaluation_string = query_name
        for i in range(3):
            top_score = max(scores_list)
            top_song_index = scores_list.index(top_score)
            top_song_name = list(scores.keys())[top_song_index]
            # print(f"{i + 1}. Matching song name: {top_song_name}, Matching function: {top_score}")
            evaluation_string += "    " + top_song_name + ".wav"
            scores.pop(top_song_name)
            scores_list.pop(top_song_index)
        print(evaluation_string)
        evaluation_string += "\n"
        output_text = open(output_txt_path,"a")
        output_text.write(evaluation_string)


def matching_function(query_fingerprint, document_fingerprint):

    # initialise empty dictionary to store results
    indicator_functions = {}
    # for each hash in the query
    for h in list(query_fingerprint.keys()):
        # check if the hash exists in the database
        if h in document_fingerprint:
            # take the query timestamp n and subtract it from
            # each database timestamp in that hash to compute shift index
            for query_n in query_fingerprint[h]:
                for database_n in document_fingerprint[h]:
                    shift_index = database_n - query_n
                    # Check if we've already counted that shift index
                    if shift_index in indicator_functions:
                        # If so, add a point
                        indicator_functions[shift_index] += 1
                    # If not, add it to the dictionary now
                    else:
                        indicator_functions[shift_index] = 1
        else:
            continue
    # Find matching function i.e. largest sum of indicator functions at a given timestamp
    return max(indicator_functions.values())