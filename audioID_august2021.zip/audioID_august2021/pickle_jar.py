from binpickle import dump, load

def store_file(filename, inverted_list, output_path):

    dump(inverted_list, f"{output_path}\{filename}.bpk")


def read_file(filename, filepath):

    inverted_list = load(f"{filepath}\{filename}.bpk")
    return inverted_list