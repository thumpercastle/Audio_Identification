import numpy as np
import librosa
import librosa.display
import matplotlib.pyplot as plt
from skimage.feature import peak_local_max
from pickle_jar import store_file
import os
import pandas as pd


def fingerprintBuilder(path_to_database, path_to_fingerprints):

    print(os.listdir(path_to_database))
    for file in os.listdir(path_to_database):
        print(file)
        # Skip over files which are not wavs
        if os.path.splitext(os.path.basename(file))[1] != ".wav":
            print("skipped")
            continue

        else:
            filename = os.path.splitext(os.path.basename(file))[0]
            # print(filename)
            filepath = os.path.join(path_to_database, os.path.basename(file))
            # print(filepath)
            # compute constellation
            coordinates = create_constellation_map(filepath)
            # print(coordinates)
            # compute hashes, return dataFrame
            hashes = compute_hashes(coordinates)
            # compute inverted lists
            inverted_lists = compute_inverted_lists(hashes)
            # store fingerprint in a pickle
            store_file(filename, inverted_lists, path_to_fingerprints)
            print("pickle complete")


def create_constellation_map(filepath):

    x, sr = librosa.load(os.path.join(filepath), sr=22050)
    magnitude_spectrogram = np.abs(librosa.stft(x, n_fft=2048, hop_length=512, win_length=2048, window="hann"))
    constellation_map = peak_local_max(np.log(magnitude_spectrogram), min_distance=10, threshold_rel=0.05,
                                       indices=False)

    # indices parameter in peak_local_max needs to be True for plots
    # # plot STFT
    # plt.figure(figsize=(10, 5))
    # librosa.display.specshow(librosa.amplitude_to_db(magnitude_spectrogram, ref=np.max), y_axis='linear',
    #                          x_axis='time', cmap='gray_r', sr=sr)
    # plt.show()
    #
    # # plot constellation map
    # constellation_coordinates = peak_local_max(np.log(magnitude_spectrogram), min_distance=10, threshold_rel=0.05,
    #                                    indices=False)
    # plt.figure(figsize=(10, 5))
    # plt.imshow(constellation_coordinates, cmap=plt.cm.gray_r, origin='lower')
    # plt.show()

    return constellation_map


def compute_hashes(coordinates):

    rows, cols = coordinates.shape
    number_to_group_rows_by = 5
    number_to_group_cols_by = 1
    # convert coordinates to pandas DF
    coordinates_df = pd.DataFrame(coordinates)
    # group rows
    hashes = coordinates_df.groupby(coordinates_df.index // number_to_group_rows_by).sum().copy(deep=True)
    # group cols
    hashes = hashes.groupby(coordinates_df.columns // number_to_group_cols_by, axis=1).sum().copy(deep=True)
    # binary mask
    hashes = hashes.mask(hashes > 0, 1).copy(deep=True)
    # drop rows where no peak exists
    hashes.where(hashes != 0, inplace=True)
    hashes.dropna(axis=0, how='all', inplace=True)
    hashes = hashes.fillna(0).copy(deep=True)

    return hashes


def compute_inverted_lists(hashes):

    # initialise empty dictionary to store the inverted lists (dictionary of lists at each hash)
    hashes_dictionary = {}
    # print("checkpoint 1")
    hashes.where(hashes != 0, inplace=True)
    for hash in hashes.index.to_list():
        # drop hashes which are not 0
        hashes_dictionary[hash] = hashes.loc[hash].dropna().index.to_list()

    print(hashes_dictionary)
    return hashes_dictionary